# cat_core
Cat engine core
