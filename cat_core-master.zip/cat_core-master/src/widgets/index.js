import * as page from './page'

export const Page = page